	            <div class="row">
                     <div class="col" style="color:#880000;font-size:24px">
                         <b>PIZZAS</b>
                    </div>	
                </div>
            	<div class="row" style="overflow:hidden;text-align:center;height:320px;">
                    <div style="margin:0px 0px 0px 0px 0px;padding:0px 0px 0px 0px;background:white;">
            			<div  class="owl-carousel" style="margin: 0 0 0 0;padding: 0 0 0 0;" >
                    		<div class=" produtos pizza" style="height:320px;">
                                <hr  class="barra_verde_dinamica"></hr>
                                <div class="btn btn-success botao_comprar ">Comprar</div>
                                <img class="card-img-top" src="/logo.png" alt="Card image cap">
                                <h6 class="card-title" style=""><b>01 A MODA DA CASA</b></h6>
                                <p class="card-text">Molho de Tomate Artesanal, Mussarela, Carne, Calabresa, Catupiry, Batata Palha, Tomate Seco Artesanal, Orégano</p>
                                <p class="card-text" style="color:#880000;"><b>R$ 68,00</b></p>
                            </div>	
                    		<div class=" produtos pizza" style="height:320px;">
                                <hr  class="barra_verde_dinamica"></hr>
                                <div class="btn btn-success botao_comprar ">Comprar</div>
                                <img class="card-img-top" src="/logo.png" alt="Card image cap">
                                <h6 class="card-title" style=""><b>01 A MODA DA CASA</b></h6>
                                <p class="card-text">Molho de Tomate Artesanal, Mussarela, Carne, Calabresa, Catupiry, Batata Palha, Tomate Seco Artesanal, Orégano</p>
                                <p class="card-text" style="color:#880000;"><b>R$ 68,00</b></p>
                            </div>	
                    		<div class=" produtos pizza" style="height:320px;">
                                <hr  class="barra_verde_dinamica"></hr>
                                <div class="btn btn-success botao_comprar ">Comprar</div>
                                <img class="card-img-top" src="/logo.png" alt="Card image cap">
                                <h6 class="card-title" style=""><b>01 A MODA DA CASA</b></h6>
                                <p class="card-text">Molho de Tomate Artesanal, Mussarela, Carne, Calabresa, Catupiry, Batata Palha, Tomate Seco Artesanal, Orégano</p>
                                <p class="card-text" style="color:#880000;"><b>R$ 68,00</b></p>
                            </div>	
                    		<div class=" produtos pizza" style="height:320px;">
                                <hr  class="barra_verde_dinamica"></hr>
                                <div class="btn btn-success botao_comprar ">Comprar</div>
                                <img class="card-img-top" src="/logo.png" alt="Card image cap">
                                <h6 class="card-title" style=""><b>01 A MODA DA CASA</b></h6>
                                <p class="card-text">Molho de Tomate Artesanal, Mussarela, Carne, Calabresa, Catupiry, Batata Palha, Tomate Seco Artesanal, Orégano</p>
                                <p class="card-text" style="color:#880000;"><b>R$ 68,00</b></p>
                            </div>	
                    		<div class=" produtos pizza" style="height:320px;">
                                <hr  class="barra_verde_dinamica"></hr>
                                <div class="btn btn-success botao_comprar ">Comprar</div>
                                <img class="card-img-top" src="/logo.png" alt="Card image cap">
                                <h6 class="card-title" style=""><b>01 A MODA DA CASA</b></h6>
                                <p class="card-text">Molho de Tomate Artesanal, Mussarela, Carne, Calabresa, Catupiry, Batata Palha, Tomate Seco Artesanal, Orégano</p>
                                <p class="card-text" style="color:#880000;"><b>R$ 68,00</b></p>
                            </div>	
                    		<div class=" produtos pizza" style="height:320px;">
                                <hr  class="barra_verde_dinamica"></hr>
                                <div class="btn btn-success botao_comprar ">Comprar</div>
                                <img class="card-img-top" src="/logo.png" alt="Card image cap">
                                <h6 class="card-title" style=""><b>01 A MODA DA CASA</b></h6>
                                <p class="card-text">Molho de Tomate Artesanal, Mussarela, Carne, Calabresa, Catupiry, Batata Palha, Tomate Seco Artesanal, Orégano</p>
                                <p class="card-text" style="color:#880000;"><b>R$ 68,00</b></p>
                            </div>	
                    		<div class=" produtos pizza" style="height:320px;">
                                <hr  class="barra_verde_dinamica"></hr>
                                <div class="btn btn-success botao_comprar ">Comprar</div>
                                <img class="card-img-top" src="/logo.png" alt="Card image cap">
                                <h6 class="card-title" style=""><b>01 A MODA DA CASA</b></h6>
                                <p class="card-text">Molho de Tomate Artesanal, Mussarela, Carne, Calabresa, Catupiry, Batata Palha, Tomate Seco Artesanal, Orégano</p>
                                <p class="card-text" style="color:#880000;"><b>R$ 68,00</b></p>
                            </div>
            			</div>
            		</div>       
                </div>	