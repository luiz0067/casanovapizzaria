<?php include 'top.php'?>
<h1 style="color:red;text-align:center;line-height:250px">
    Montar Pizzza
</h1>
<?php include 'foot.php'?>